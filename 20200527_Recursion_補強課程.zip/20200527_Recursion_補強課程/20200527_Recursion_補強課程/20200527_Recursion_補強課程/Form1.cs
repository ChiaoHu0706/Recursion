﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;
using vb = Microsoft.VisualBasic;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace _20200527_Recursion_補強課程
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        RecursiveFunctions RF=new RecursiveFunctions();
        string Show;
        string[] TWID = new string[10000];
        Random RN = new Random();
        private void Number_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != 8 && !char.IsDigit(e.KeyChar))
            {
                this.Text = e.KeyChar.ToString();
                e.Handled= true;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Display.Clear();
            double Starttime = System.DateTime.Now.TimeOfDay.TotalSeconds;
            try
            {
                int[] N = new int[100000];
                switch (comboBox1.SelectedIndex)
                {
                    case 0: //Factorial
                        for (byte i = 1; i <= byte.Parse(Number.Text); i++)
                        {
                            //Display.Text += i + "!=" +Factorial(i) + Environment.NewLine;//\r\n
                            Display.Text += i + "!=" + RF.RFact(i) + Environment.NewLine;//\r\n
                        }
                      
                        break;
                    case 1://Fibonacci Number
                        for(byte i = 0; i <= byte.Parse(Number.Text); i++)
                        {
                            Display.Text+="Fibonacci("+i+")="+Fibonacci(i) +"\r\n";
                            //Display.Text += "Fibonacci(" + i + ")=" + RF.RFib(i) + "\r\n";
                        }
                        break;
                    case 2:
                        decimal X = int.Parse(N1.Text);
                        decimal Y = int.Parse(N2.Text);
                        GCDValue.Text = GCD(X, Y).ToString();
                        LCMValue.Text = LCM(X, Y).ToString();
                        break;
                    case 3:
                       
                        
                        
                        //Bubble Sort
                        int temp;
                        for (int i = 1; i < int.Parse(Number.Text); i++)
                        {
                            for (int j = 0; j < int.Parse(Number.Text) - i; j++)
                            {
                                if (N[j] > N[j + 1])
                                {
                                    temp=N[j];
                                    N[j] = N[j + 1];
                                    N[j+ 1] = temp; 
                                }
                            }
                        }
                        break;
                    case 4:
                        int disks=int.Parse(Number.Text);
                        Display.Clear();
                        result = null;
                        steps = 0;//步驟數
                        HanoiTower(disks, "Rod[A]", "Rod[C]", "Rod[B]");
                        Display.Text = result;

                        break;
                    case 5://Recaman’s sequence
                        //https://www.geeksforgeeks.org/recamans-sequence/

                        //英文資料(English Data)
                        //https://en.wikipedia.org/wiki/Recam%C3%A1n%27s_sequence

                        //中文解釋(Chinese Explain)
                        //https://blog.csdn.net/kavu1/article/details/52410542

                        // Recaman序列的可視化
                        // https://www.youtube.com/watch?v=FGC5TdIiT9U


                       
                       Display.Clear();
                       int n = int.Parse(Number.Text)+1;
                       result=null;
                       recaman(n);
                       Display.Text += result; 

                        break;
                    case 6://Alexander Bogomolny 的無序排列算法
                        //https://www.geeksforgeeks.org/alexander-bogomolnys-unordered-permutation-algorithm/
                        //https://verytoolz.com/blog/13766ed05c/
                        result = null;
                        Display.Clear();
                        int[] perm = new int[int.Parse(Number.Text)];
                        AlexanderBogomolyn(perm, int.Parse(Number.Text), 0);
                        Display.Text += result;
                        
                        break; 
                    case 7://Sum triangle from array
                        //https://www.geeksforgeeks.org/sum-triangle-from-array/
                        Display.Clear();
                        result = null;
                        int L = int.Parse(vb.Interaction.InputBox("請輸入三角形層數的(整數)"));
                        int[] a = new int[L];
                        for(int m=0; m <= a.Length-1; m++)
                        {
                            a[m]= int.Parse(vb.Interaction.InputBox("請輸入數字(整數)"));
                        }
                        int G = a.Length;
                        printTriangle(a, G);
                        Display.Text += result;
                        break;
                    case 8:
                       Show = null;
                        for (int i = 0; i <= int.Parse(Number.Text); i++)
                        {
                            N[i] = RN.Next(0, 1000);
                            Show += N[i] + ", ";
                        }
                        Show += Environment.NewLine;
                        Display.Text = Show + Environment.NewLine +
                             "================= Sorted ==================" + Environment.NewLine;

                        //Bubble Sort
                        //Bubble(N, 0, int.Parse(Number.Text)-1);
                        RF.BubbleSort(N, 0, int.Parse(Number.Text) - 1);
                        Show = null;
                        for(int i = 0; i < int.Parse(Number.Text); i++)
                        {
                            Show += N[i] + ", ";
                        }
                        Display.Text += Show;

                        break;
                    case 9:
                        SaveFileDialog SFD = new SaveFileDialog();
                        SFD.Filter = "文字檔|*.txt";
                        SFD.Title = "選擇儲存原始ID檔案";
                        if (SFD.ShowDialog() == DialogResult.OK)
                        {
                            using (StreamWriter SW = new StreamWriter(SFD.FileName, false))
                            {
                                for (int i = 0; i < 10000; i++)
                                {
                                    TWID[i] = ((char)RN.Next(65, 91)).ToString();
                                    TWID[i] += RN.Next(1, 3).ToString();
                                    for (int j = 1; j <= 8; j++) TWID[i] += RN.Next(0, 10);
                                    SW.WriteLine(i + ". " + TWID[i]);
                                }
                            }
                        }
                        else return;
                        System.Diagnostics.Process.Start(SFD.FileName);
                        //Bubble Sort
                        this.Text = "Sorting.......";
                        string temp2;
                        for (int i = 1; i < 10000; i++)
                        {
                            for(int j=0; j < 10000 - i; j++)
                            {
                                if (string.Compare(TWID[j], TWID[j + 1]) > 0)
                                {
                                    temp2 = TWID[j];
                                    TWID[j] = TWID[j + 1];
                                    TWID[j + 1] = temp2;
                                }
                            }
                        }
                        this.Text = null;
                        SFD.Title = "選擇儲存排序ID檔案";
                        if (SFD.ShowDialog() == DialogResult.OK)
                        {
                            using (StreamWriter SW = new StreamWriter(SFD.FileName, false))
                            {
                                for (int i = 0; i < 10000; i++)
                                {

                                    SW.WriteLine("ID[" + i + "]= " + TWID[i]);
                                }
                            }
                        }
                        else return;
                        System.Diagnostics.Process.Start(SFD.FileName);
                        break;
                    case 10:
                        int index = BinarySearch(TWID, Number.Text, 0, 9999);
                        //int index=RF.BinarySearch(TWID,Number.Text,0,9999);
                        if (index == -1) Display.Text = "檔案中無此身分證字號";
                        else Display.Text = "TWID[" + index + "] = " + TWID[index];
                        break;
                    case 11:
                        //https://www.geeksforgeeks.org/decimal-binary-number-using-recursion/
                        int Q = int.Parse(Number.Text);
                        List<int> single_list = new List<int>();
                        compute_factors(2,Q,1,single_list);


                        break;

                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                double FinishTime = System.DateTime.Now.TimeOfDay.TotalSeconds;
                this.Text = Math.Round(FinishTime - Starttime, 2) + "毫秒[10^(-3)]";
            }
        }
        string result;
        public int steps;
        //<summary>

        //</summary>
        //<param name = "N">Disks數量 </param>
        //< param name> = "Source">來源Rod </param>
        //<param name> = "Destination">目的Rod </param>
        //< param name> = "Via">經過Rod </param>
        //<remarks></remarks>
        public void HanoiTower(int N,string Source,string Destination,string Via)
        {
            if (N == 1)
            {
                steps++;
                result += steps + ". Move Disk " + N + "From" + Source + " To " + Destination+"\r\n";
            }
            else
            {
                HanoiTower(N - 1, Source, Via, Destination);
                steps++;
                result+=steps+". Move Disk "+N+"From"+ Source + " To " + Destination + "\r\n";
                HanoiTower(N - 1, Via, Destination, Source);
            }
        }
        //Probelm-Slove
        // 1: Forwarding
        // 2: Backwarding
        // HanoiTower(4,"A","C","B")
        // HanoiTower(3,"A","B","C")
        // Move 4 from A to C
        // HanoiTower(3,"B","C","A")
        static decimal Factorial(int x)
        {
            checked
            {
                decimal f;
                if (x < 0) return -1;
                else if (x == 0 || x == 1) return 1;
                else
                {

                    f = 1;
                    for (int i = x; i > 0; i--)
                    {
                        f *= i;
                    }
                    return f;
                }
            }
        }
        static decimal Fibonacci(int x)
        {
            if (x < 0) return -1;
            else if (x == 0) return 0;
            else if (x == 1) return 1;
            else
            {
                decimal F0 = 0;
                decimal F1 = 1;
                decimal Fn = 0;
                decimal f = 2;
                while (f <= x)
                {
                    Fn = F0 + F1;
                    F0 = F1;
                    F1 = Fn;
                    f++;
                }
                return Fn;
            }
        }
        static bool PrimeYesNo(decimal X)
        {
            //3.
            if (X <= 1) return false;
            else if (X % 2 == 0) return false;
            else
            {
                //for(decimal i = 3; i < X ; i+=2)
                //for (decimal i = 3; i < (decimal)Math.Pow((double)X, 1.0 / 2.0); i += 2)
                //for (decimal i = 3; i < (decimal)Math.Sqrt((double)X); i += 2)
                for (decimal i = 3; i * i < X; i += 2)
                {
                    if (X % i == 0) return false;
                }
                return true;//is primenumber
            }
            //2.Performance
            //if (X <= 1) return false;
            //else if (X % 2 == 0) return false;
            //else
            //{
            //    //for(decimal i = 3; i < X ; i+=2)
            //    for (decimal i = 3; i < X; i += 2)
            //    {
            //        if (X % i == 0) return false;
            //    }
            //    return true;//is primenumber
            //}




            //1.Definition
            //if (X <= 1) return false;
            //else
            //{
            //    for (decimal i = 2; i < X; i++)
            //    {
            //        if (X % i == 0) return false;
            //    }
            //    return true;//is primenumber
            //}


        }
        static decimal GCD(decimal a, decimal b)
        {
            if (a < 0) a = -a;
            if (b < 0) b = -b;
            decimal R;
            while (a % b != 0)
            {

                R = a % b;
                a = b;
                b = R;
            }
            return b;
        }

        static decimal LCM(decimal a, decimal b)
        {
            return Math.Abs(a * b) / GCD(a, b);
        }
        public void recaman(int n)
        {
            //題意
            //一組數列，從第一項開始，每一項根據前一項獲得，對於第m項，如果am-1-m>0 && am在之前的數列中未出現過，則am=am-1-m;否則am=am-1+m

            // Create an array to store terms
            int[] arr = new int[n];

            // First term of the sequence is always 0
            arr[0] = 0;

            result = "a0 ： "+arr[0]  +"\r\n";
            // Fill remaining terms using recursive
            // formula.
            for (int i = 1; i < n; i++)
            {
                int curr = arr[i - 1] - i;
                int j;
                
                for (j = 0; j < i; j++)
                {
                    // If arr[i-1] - i is negative or
                    // already exists.
                    if ((arr[j] == curr) || curr < 0)
                    {
                        curr = arr[i - 1] + i;
                        break;
                    }
                }

                arr[i] = curr;
                result+= "a"+i+" ： "+ arr[i] + "\r\n";

            }
        }
        static int level = -1;

        // A function to print
        // the permutation.
        public void print(int[] perm,int N)
        {

            for (int i = 0; i < N; i++)
               
                result += " " + perm[i];
            
                result += "\r\n";
          
        }

        // A function implementing
        // Alexander Bogomolny algorithm.
        public void AlexanderBogomolyn(int[] perm,int N, int k)
        {

            // Assign level to
            // zero at start.
            level = level + 1;
            perm[k] = level;

            if (level == N)
                print(perm, N);
            
            else
                for (int i = 0; i < N; i++)

                    // Assign values
                    // to the array
                    // if it is zero.
                    if (perm[i] == 0)
                        AlexanderBogomolyn(perm, N, i);

            // Decrement the level
            // after all possible
            // permutation after
            // that level.
            level = level - 1;

            perm[k] = 0;
        }


        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            //MessageBox.Show("Say Bye Bye Again!!","提示訊息",MessageBoxButtons.OK,MessageBoxIcon.Information);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult dr = MessageBox.Show("確定是否關閉視窗?","提示訊息",MessageBoxButtons.YesNo,MessageBoxIcon.Question);
            switch (dr)
            {
                case System.Windows.Forms.DialogResult.Yes:e.Cancel = false;break;
                case System.Windows.Forms.DialogResult.No:e.Cancel = true;break;
            }
        }

        public void printTriangle(int[] A, int n)
        {
            // Base case
            if (n < 1)
                return;

            // Creating new array which contains the
            // Sum of consecutive elements in
            // the array passes as parameter.
            int[] temp = new int[n - 1];
            for (int i = 0; i < n - 1; i++)
            {
                int x = A[i] + A[i + 1];
                temp[i] = x;
            }

            // Make a recursive call and pass
            // the newly created array
            printTriangle(temp, n - 1);

            // Print current array in the end so
            // that smaller arrays are printed first
            for (int i = 0; i < n; i++)
            {
                if (i == n - 1)
                    result+=A[i] + " ";
                else
                   result+=A[i] + ", ";
            }

           result+="\r\n" ;
        }


        private void Bubble (int[] N ,int first,int last)
        {
            int temp;
            for (int i = 1; i < int.Parse(Number.Text); i++)
            {
                for (int j = 0; j <= int.Parse(Number.Text) - i; j++)
                {
                    if (N[j] > N[j+1])
                    {
                        temp= N[j];
                        N[j] = N[j+1];
                        N[j+1] = temp;
                    }
                }
            }
        }

        private int BinarySearch(string[] ID,string X,int first,int last)
        {
            int ptr = (first + last) / 2;
            while (ptr <= last && ptr >= first)
            {
                if (ID[ptr] == X) return ptr;
                else if (string.Compare(X, ID[ptr]) > 0) first = ptr + 1;
                else last = ptr-1;
                ptr = (first + last) / 2;
            }
            return -1;
        }

        public List<List<int>> factors_combination = new List<List<int>>();

        // recursive function
        public void compute_factors(int current_no, int n, int product, List<int> single_list)
        {

            // base case: if the product
            // exceeds our given number;
            // OR
            // current_no exceeds half the given n
            if (current_no > (n / 2) || product > n)
                return;

            // if current list of factors
            // is contributing to n
            if (product == n)
            {

                // storing the list
                factors_combination.Add(single_list);
                // printing all possible factors stored in
                // factors_combination
                for (int i = 0; i < factors_combination.Count; i++)
                {
                    for (int j = 0; j < factors_combination[i].Count; j++)
                        Display.Text+=factors_combination[i][j] + " ";
                }
                Display.Text += Environment.NewLine;
                factors_combination = new List<List<int>>();
                // into factors_combination
                return;
            }

            // including current_no in our list
            single_list.Add(current_no);

            // trying to get required
            // n with including current
            // current_no
            compute_factors(current_no, n, product * current_no, single_list);

            // excluding current_no from our list
            single_list.RemoveAt(single_list.Count - 1);

            // trying to get required n
            // without including current
            // current_no
            compute_factors(current_no + 1, n, product, single_list);
        }
    }
}
