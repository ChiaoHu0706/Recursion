﻿namespace _20200527_Recursion_補強課程
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.Display = new System.Windows.Forms.TextBox();
            this.Number = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.LCMValue = new System.Windows.Forms.TextBox();
            this.GCDValue = new System.Windows.Forms.TextBox();
            this.N2 = new System.Windows.Forms.TextBox();
            this.N1 = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.comboBox1.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Factorial",
            "Fibonacci Number",
            "GCD & LCM",
            "Quick Sort",
            "HanoiTower",
            "Recaman’s sequence",
            "Alexander Bogomolny’s UnOrdered Permutation Algorithm",
            "Sum triangle from array"});
            this.comboBox1.Location = new System.Drawing.Point(515, 95);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(213, 32);
            this.comboBox1.TabIndex = 0;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // Display
            // 
            this.Display.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Display.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Display.Location = new System.Drawing.Point(30, 95);
            this.Display.Multiline = true;
            this.Display.Name = "Display";
            this.Display.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.Display.Size = new System.Drawing.Size(399, 331);
            this.Display.TabIndex = 1;
            // 
            // Number
            // 
            this.Number.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Number.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Number.Location = new System.Drawing.Point(515, 27);
            this.Number.Name = "Number";
            this.Number.Size = new System.Drawing.Size(213, 33);
            this.Number.TabIndex = 2;
            this.Number.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Number_KeyPress);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.groupBox1.Controls.Add(this.LCMValue);
            this.groupBox1.Controls.Add(this.GCDValue);
            this.groupBox1.Controls.Add(this.N2);
            this.groupBox1.Controls.Add(this.N1);
            this.groupBox1.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox1.Location = new System.Drawing.Point(515, 162);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(213, 264);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "GCD-LCM";
            // 
            // LCMValue
            // 
            this.LCMValue.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.LCMValue.Location = new System.Drawing.Point(35, 191);
            this.LCMValue.Multiline = true;
            this.LCMValue.Name = "LCMValue";
            this.LCMValue.Size = new System.Drawing.Size(149, 43);
            this.LCMValue.TabIndex = 3;
            // 
            // GCDValue
            // 
            this.GCDValue.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.GCDValue.Location = new System.Drawing.Point(35, 132);
            this.GCDValue.Multiline = true;
            this.GCDValue.Name = "GCDValue";
            this.GCDValue.Size = new System.Drawing.Size(149, 39);
            this.GCDValue.TabIndex = 2;
            // 
            // N2
            // 
            this.N2.Location = new System.Drawing.Point(35, 82);
            this.N2.Name = "N2";
            this.N2.Size = new System.Drawing.Size(149, 29);
            this.N2.TabIndex = 1;
            // 
            // N1
            // 
            this.N1.Location = new System.Drawing.Point(35, 28);
            this.N1.Name = "N1";
            this.N1.Size = new System.Drawing.Size(149, 29);
            this.N1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(30, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(399, 77);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Number);
            this.Controls.Add(this.Display);
            this.Controls.Add(this.comboBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox Display;
        private System.Windows.Forms.TextBox Number;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox LCMValue;
        private System.Windows.Forms.TextBox GCDValue;
        private System.Windows.Forms.TextBox N2;
        private System.Windows.Forms.TextBox N1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

