﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20200527_Recursion_補強課程
{
    internal class RecursiveFunctions
    {
        public decimal RFact(ulong n)//Recursive Factorial
        {
            checked
            {
                if (n == 0 || n == 1) return 1;
                else return n*RFact(n-1);
            }
        }
        public decimal RFib(decimal n)
        {
            checked
            {
                if (n == 0) return 0;
                else if (n == 1) return 1;
                else
                {
                    return RFib(n-1)+RFib(n-2);
                }
            }
        }
        public decimal Rgcd(decimal x,decimal y)
        {
            if (x >= y)
            {
                if (x % y == 0) { return y; } //等於0代表整除,取較小數
                else { return Rgcd(y, x % y); }//遞迴呼叫
                
            }
            else
            {
                if (y%x==0) { return x; }
                else { return Rgcd(x,y%x); }
            }
        }
    }

}
